package lk.ijse.carRental.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author : Hasitha Lakshan
 * Project :CarRentalSystem
 * Date :2/17/2023
 * Time :12:16 AM
 */

/*@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString*/
public class PaymentDTO {
}
