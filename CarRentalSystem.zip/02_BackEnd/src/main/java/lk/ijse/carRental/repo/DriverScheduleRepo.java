package lk.ijse.carRental.repo;

import lk.ijse.carRental.entity.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author : Hasitha Lakshan
 * Project Name: CarRentalSystem
 * Date        : 3/8/2023
 * Time        : 12:17 PM
 */

public interface DriverScheduleRepo extends JpaRepository<lk.ijse.carRental.entity.DriverSchedule,String> {

}
