package lk.ijse.carRental.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author : Hasitha Lakshan
 * Project :CarRentalSystem
 * Date :2/16/2023
 * Time :11:59 PM
 */

@RestController
@RequestMapping("/payment")
@CrossOrigin
public class PaymentController {
}
